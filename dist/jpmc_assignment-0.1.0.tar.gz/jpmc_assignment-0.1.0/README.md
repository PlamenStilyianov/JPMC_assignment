### Assignment – Super Simple Stock Market
![img_2.png](uml_images/text.png)
![img.png](uml_images/simple_stock_market_uml.png)
![img.png](uml_images/tests_passed.png)
![img_1.png](uml_images/poetry_build.png)
![img_1.png](uml_images/trying_package.png)
